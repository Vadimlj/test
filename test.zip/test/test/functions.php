<?php

function theme_register_nav_menu() {
    register_nav_menus(
        array(
            'primary' => __( 'Primary Menu', 'test' )
        )
    );
}

add_action( 'after_setup_theme', 'theme_register_nav_menu' );


/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function twentynineteen_widgets_init() {

    register_sidebar(
        array(
            'name'          => __( 'Footer', 'test' ),
            'id'            => 'sidebar-1',
            'description'   => __( 'Add widgets here to appear in your footer.', 'test' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        )
    );

}
add_action( 'widgets_init', 'twentynineteen_widgets_init' );

function include_myscript_and_styles() {
    wp_enqueue_script( 'jquery', get_stylesheet_directory_uri() . '/js/jquery.min.js', array(),
        null, true );
    wp_enqueue_script( 'bootstrap', get_stylesheet_directory_uri() . '/js/bootstrap.min.js', array(),
        null, true );
    wp_enqueue_style( 'main_css', get_template_directory_uri() . '/css/main.css', array(), '' );
}
add_action( 'wp_enqueue_scripts', 'include_myscript_and_styles' );


/**
 * Добавляем СРТ
 */

function create_posttype() {
    register_post_type( 'news',
// CPT Options
        array(
            'labels' => array(
                'name' => __( 'Новости' ),
                'singular_name' => __( 'News' )
            ),
            'public' => true,
            'has_archive' => false,
            'rewrite' => array('slug' => 'news'),
        )
    );
}
// Hooking up our function to theme setup
add_action( 'init', 'create_posttype' );

function cw_post_type_news() {
    $supports = array(
        'title', // post title
        'editor', // post content
        'author', // post author
        'thumbnail', // featured images
        'excerpt', // post excerpt
        'custom-fields', // custom fields
        'comments', // post comments
        'revisions', // post revisions
        'post-formats', // post formats
    );
    $labels = array(
        'name' => _x('Новости', 'plural'),
        'singular_name' => _x('Новости', 'singular'),
        'menu_name' => _x('Новости', 'admin menu'),
        'name_admin_bar' => _x('Новости', 'admin bar'),
        'add_new' => _x('Добавить новость', 'add new'),
        'add_new_item' => __('Добавить новую'),
        'new_item' => __('Последние'),
        'edit_item' => __('Редактировать'),
        'view_item' => __('Просмотр'),
        'all_items' => __('Все'),
        'search_items' => __('Искать новость'),
        'not_found' => __('Не найдено.'),
    );
    $args = array(
        'supports' => $supports,
        'labels' => $labels,
        'public' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'news'),
        'has_archive' => true,
        'hierarchical' => false,
    );
    register_post_type('news', $args);
}
add_action('init', 'cw_post_type_news');

function km_remote_image_file_exists( $url ) {
    $response = wp_remote_head( $url );
    return 200 === wp_remote_retrieve_response_code( $response );
}
function Generate_HELLOW() {
    return '<div class="test-shortcode">Hello Wordl! Я шорт тег</div>';
}
add_shortcode('HELLOW', 'Generate_HELLOW');

