<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since 1.0.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <header>
        <div class="top-line">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-3 col-md-6">
                        <a href="<?php home_url( '/' )?>">
                                    <span class="logo">
                                        <img src="<?php print_r(get_stylesheet_directory_uri() . '/img/logo.svg') ?>"
                                             alt="">
                                    </span>
                            <span class="logo-title d-none d-md-inline-block">AwesomeDesign</span>
                        </a>
                    </div>
                    <div class="col-9 col-md-6 text-right">
                        <a class="cellphone" href="tel:360 690 67 89">+360 690 67 89</a>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div class="site-wr">
        <div class="container">

            <div class="row">

                <div class="col-12">
                    <nav class="navbar navbar-expand-lg justify-content-between justify-content-lg-end navbar-dark">
                        <button class="navbar-toggler order-2" type="button" data-toggle="collapse"
                                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse order-2 order-lg-1" id="navbarSupportedContent">

                            <?php
                                get_search_form();
                                $menu_name = 'primary';
                                $locations = get_nav_menu_locations();

                                if( $locations && isset( $locations[ $menu_name ] ) ){

                                    // получаем элементы меню
                                    $menu_items = wp_get_nav_menu_items( $locations[ $menu_name ] );

                                    // создаем список
                                    $menu_list = '<ul class="navbar-nav ml-auto py-4 py-md-0">';

                                    foreach ( (array) $menu_items as $key => $menu_item ){
                                        $menu_list .= '<li class="nav-item"><a class="nav-link" href="' .
                                            $menu_item->url . '">' .
                                            $menu_item->title .
                                            '</a></li>';
                                    }

                                    $menu_list .= '</ul>';
                                }

                            ?>
                            <?php if ( has_nav_menu( 'primary' ) ) {
                                echo $menu_list;
                            } ?>
                        </div>
                        <a href="#" class="btn btn-success btn-custom order-1 order-lg-2">Contact</a>
                    </nav>
                </div>
                <div class="col-12">