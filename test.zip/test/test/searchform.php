
<form role="search" method="get" class="form-inline form-custom" action="<?php echo home_url( '/' ) ?>">
    <input class="form-control form-control-search" type="text" placeholder="Search" value="<?php echo get_search_query() ?>" name="s">
</form>