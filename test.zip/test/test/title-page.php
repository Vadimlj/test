<?php
/*
Template Name: Титульная страница
*/
get_header();
?>

<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <div class="row">
                <div class="col-md-5">
                    <div class="d-flex align-items-start flex-column bd-highlight h-100 article-wr">
                        <div class="bd-highlight article-time">
                            <img src="<?php print_r(get_stylesheet_directory_uri() . '/img/clock.svg') ?>" alt="">26, January 2019
</div>
                        <div class="bd-highlight article-title">
Researchers design robot glider that takes off from water
</div>
                        <a href="/"
                           class="mt-auto bd-highlight btn btn-success btn-custom btn-article">Read More</a>
                    </div>
                </div>
                <div class="col-md-7">
                    <img src="<?php print_r(get_stylesheet_directory_uri() . '/tmp/slide1.jpg') ?>" alt="First slide">
                </div>
            </div>
        </div>

        <div class="carousel-item">
            <div class="row">
                <div class="col-md-5">
                    <div class="d-flex align-items-start flex-column bd-highlight h-100 article-wr">
                        <div class="bd-highlight article-time">
                            <img src="<?php print_r(get_stylesheet_directory_uri() . '/img/clock.svg') ?>" alt="">26,
                            January 2019
</div>
                        <div class="bd-highlight article-title">
Researchers design robot glider that takes off from water
</div>
                        <a href="/"
                           class="mt-auto bd-highlight btn btn-success btn-custom btn-article">Read More</a>
                    </div>
                </div>
                <div class="col-md-7">
                    <img src="<?php print_r(get_stylesheet_directory_uri() . '/tmp/slide1.jpg') ?>" alt="First slide">
                </div>
            </div>
        </div>
    </div>
    <div class="custom-nav-wr">
        <a class="custom-nav custom-nav-prev" href="#carouselExampleControls" role="button"
           data-slide="prev">
        </a>
        <a class="custom-nav custom-nav-next" href="#carouselExampleControls" role="button"
           data-slide="next">
        </a>
    </div>
</div>


<div class="information-block">
    <?php
    $about_note = get_field( "about_us_note" );
    $about_title = get_field( "about_us_title" );
    if ($about_note &&  $about_title) {
        echo "<div class='about-us'>
            <h1 class='about-us-title block-title'>" . $about_title . "</h1>
            <div class='about-us-text'>
                <p>" . $about_note . "</p>
            </div>
        </div>";
    }?>

<?php  query_posts(array(
    'post_type' => 'news'
));
if( have_posts() ) {
    ?>
    <div class="news-block">
        <div class="news-block-title block-title">Our News</div>
        <div class="news-block-list">

            <?php while (have_posts()) : the_post();
                $image = get_field("news_image", get_the_ID());
                $img_url = get_stylesheet_directory_uri() . '/tmp/n1.jpg';
                $img_alt = "test_image";

                if( !empty($image) && km_remote_image_file_exists($image['url'])) {
                    $img_url = $image['url'];
                    $img_alt = $image['alt'];
                }
            ?>
                <div class="news-block-list-item">
                    <div class="new-block-list-item-img">
                        <img src="<?php _e($img_url, "test") ?>" alt="">
                    </div>
                    <div class="new-block-list-item-block">
                        <div class="new-block-list-item-block-date"><?php the_time( "j F Y" ); ?></div>
                        <div class="new-block-list-item-block-note">
                            <p>
                                <?php the_excerpt(); ?>
                            </p>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>

        </div>
    </div>

    </div>


    <?php
}
get_footer();
?>