<?php
/**
 * Created by PhpStorm.
 * User: macos
 * Date: 10.10.2019
 * Time: 12:18
 */

?>

</div>

</div>
</div>
</div>


<footer>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <a href="<?php home_url( '/' )?>">
                            <span class="logo logo-bottom">
                                <img src="<?php print_r(get_stylesheet_directory_uri() . '/img/logo.svg') ?>" alt="">
                            </span>
                    <span class="logo-title logo-title-bottom">AwesomeDesign</span>
                </a>
            </div>
        </div>
    </div>
</footer>
<?php wp_footer() ?>
</body>
</html>
